<!-- footer file-->
<footer>
    <p>
        Copyright&copy; Samuele Facenda <?php echo date("Y"); ?>
    </p>
</footer>